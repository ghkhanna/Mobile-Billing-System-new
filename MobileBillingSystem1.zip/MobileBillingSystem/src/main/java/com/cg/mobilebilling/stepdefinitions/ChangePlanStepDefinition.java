package com.cg.mobilebilling.stepdefinitions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChangePlanStepDefinition {
	@Given("^User is on view plan details page$")
	public void user_is_on_view_plan_details_page() throws Throwable {
		
	}

	@When("^User enters valid customer id and mobile number$")
	public void user_enters_valid_customer_id_and_mobile_number() throws Throwable {
	}

	@Then("^display plan details$")
	public void display_plan_details() throws Throwable {
	}

	@When("^User enters incorrect customer id$")
	public void user_enters_incorrect_customer_id() throws Throwable {
	}

	@Then("^display customer id not found message$")
	public void display_customer_id_not_found_message() throws Throwable {
	}

	@When("^User enters incorrect mobile number$")
	public void user_enters_incorrect_mobile_number() throws Throwable {
	}

	@Then("^display invalid mobile number error message$")
	public void display_invalid_mobile_number_error_message() throws Throwable {
	}

	@When("^User enters incorrect plan id$")
	public void user_enters_incorrect_plan_id() throws Throwable {
	}

	@Then("^display invalid plan id error message$")
	public void display_invalid_plan_id_error_message() throws Throwable {
	}
}
