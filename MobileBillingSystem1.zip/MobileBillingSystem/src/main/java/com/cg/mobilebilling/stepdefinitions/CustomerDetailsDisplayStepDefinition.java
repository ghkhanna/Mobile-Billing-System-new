package com.cg.mobilebilling.stepdefinitions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.CustomerDetailsPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class CustomerDetailsDisplayStepDefinition {
	private WebDriver driver;
	private CustomerDetailsPage customerDetailsPage;
	
	@Given("^User is on view customer details page$")
	public void user_is_on_view_customer_details_page() throws Throwable {
		System.setProperty("wendriver.chrome.driver", "D:\\");
		driver = new ChromeDriver();
		driver.get("http://localhost:5555/customerDetails");
		customerDetailsPage=PageFactory.initElements(driver,CustomerDetailsPage.class);
	}

	@When("^User enters coorect customer id and mobile number$")
	public void user_enters_coorect_customer_id_and_mobile_number() throws Throwable {
		customerDetailsPage.setCustomerID("101");
		customerDetailsPage.setMobileNo("987650001");
	}

	@Then("^display customer details$")
	public void display_customer_details() throws Throwable {
		String expectedTitle = "Customer Details";
		Assert.assertEquals(expectedTitle, driver.getTitle());
	}

	@When("^User inputs wrong customer id$")
	public void user_inputs_wrong_customer_id() throws Throwable {
		customerDetailsPage.setCustomerID("111");
		customerDetailsPage.setMobileNo("987650001");
	}

	@Then("^display \"([^\"]*)\" error message$")
	public void display_error_message(String arg1) throws Throwable {
		
	}

	@When("^User enters Wrong mobile number$")
	public void user_enters_Wrong_mobile_number() throws Throwable {
		customerDetailsPage.setCustomerID("101");
		customerDetailsPage.setMobileNo("9876500018");
	}

	@Then("^display invalid postpaid account error message$")
	public void display_invalid_postpaid_account_error_message() throws Throwable {
	}
}
