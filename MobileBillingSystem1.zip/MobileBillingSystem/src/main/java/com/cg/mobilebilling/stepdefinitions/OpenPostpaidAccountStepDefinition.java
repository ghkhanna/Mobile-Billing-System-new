package com.cg.mobilebilling.stepdefinitions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenPostpaidAccountStepDefinition {
	@Given("^User is on plans page$")
	public void user_is_on_plans_page() throws Throwable {
		
		
	}

	@When("^User enters invalid customer id$")
	public void user_enters_invalid_customer_id() throws Throwable {
	}

	@Then("^display customer id not found error message$")
	public void display_customer_id_not_found_error_message() throws Throwable {
	}

	@When("^User enters invalid plan id$")
	public void user_enters_invalid_plan_id() throws Throwable {
	}

	@Then("^display plan id not found error message$")
	public void display_plan_id_not_found_error_message() throws Throwable {
	}

	@When("^User enters valid customer id and plan id$")
	public void user_enters_valid_customer_id_and_plan_id() throws Throwable {
	}

	@Then("^provide user a mobile number of postpaid account$")
	public void provide_user_a_mobile_number_of_postpaid_account() throws Throwable {
	}
}
