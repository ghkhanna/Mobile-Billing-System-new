package com.cg.mobilebilling.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PlanPage {
	@FindBy(how=How.NAME, name="customerID")
	private WebElement customerID;
	
	@FindBy(how=How.NAME, name="planID")
	private WebElement planID;
	
	
}
